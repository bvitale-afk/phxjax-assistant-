import PhxAssistant from './PhxAssistant'

export default function AssistantPage() {
  return <PhxAssistant />
}
